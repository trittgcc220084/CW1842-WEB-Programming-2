<template>
  <div>
    <h1>Words</h1>

    <div class="ui icon input fluid search-box">
      <input
        type="text"
        v-model="searchQuery"
        placeholder="Search by English, German or French..."
      />
      <i class="search icon"></i>
    </div>

    <table id="words" class="ui celled compact table">
      <thead>
        <tr>

          <th class="sortable" @click="sortBy('english')">
            English <i :class="sortIcon('english')"></i>
          </th>


          <th class="sortable" @click="sortBy('german')">
            German <i :class="sortIcon('german')"></i>
          </th>
          
          
          <th class="sortable" @click="sortBy('french')">
            French <i :class="sortIcon('french')"></i>
          </th>
          <th colspan="3">Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="word in displayedWords" :key="word._id">
          <td>{{ word.english }}</td>
          <td>{{ word.german }}</td>
          <td>{{ word.french }}</td>
          <td width="75" class="center aligned">
            <router-link :to="{ name: 'show', params: { id: word._id }}">Show</router-link>
          </td>
          <td width="75" class="center aligned">
            <router-link :to="{ name: 'edit', params: { id: word._id }}">Edit</router-link>
          </td>
          <td width="75" class="center aligned" @click.prevent="onDelete(word._id)">
            <a href="#">Delete</a>
          </td>
        </tr>
        <tr v-if="displayedWords.length === 0">
          <td colspan="6" class="center aligned no-results">
            No words match "{{ searchQuery }}"
          </td>
        </tr>
      </tbody>
    </table>
    <div class="add-button-wrapper">
      <router-link :to="{ name: 'new-word' }" class="ui primary button">
      <i class="plus icon"></i> Add new word
    </router-link>
    </div>
  </div>
</template>

<script>
import { api } from '../helpers/helpers';

export default {
  name: 'words',
  data: function() {
    return {
      words: [],
      searchQuery: '',
      //  The column currently being sorted and the sort direction ('asc' or 'desc')
      sortColumn: null,
      sortDirection: 'asc'
    };
  },
  computed: {
    // Filter by search keywords in all three languages.
    filteredWords() {
      const query = this.searchQuery.trim().toLowerCase();
      if (!query) return this.words;

      return this.words.filter(word =>

        (word.german || '').toLowerCase().includes(query) ||

        (word.english || '').toLowerCase().includes(query) ||
        
        (word.french || '').toLowerCase().includes(query)
      );
    },
    //Apply sorting to the filtered list.
    displayedWords() {
      if (!this.sortColumn) return this.filteredWords;

      const column = this.sortColumn;
      const direction = this.sortDirection === 'asc' ? 1 : -1;

      return [...this.filteredWords].sort((a, b) => {
        const valA = (a[column] || '').toLowerCase();
        const valB = (b[column] || '').toLowerCase();
        if (valA < valB) return -1 * direction;
        if (valA > valB) return 1 * direction;
        return 0;
      });
    }
  },
  async mounted() {
    this.words = await api.getWords();
  },
  methods: {
    sortBy(column) {
      if (this.sortColumn === column) {
        // Clicking the same column again toggles the sort order.
        this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
      } else {
        this.sortColumn = column;
        this.sortDirection = 'asc';
      }
    },
    sortIcon(column) {
      if (this.sortColumn !== column) return 'sort icon';
      return this.sortDirection === 'asc' ? 'sort up icon' : 'sort down icon';
    },
    onDelete: async function(id) {
      // Show a confirmation dialog before deleting, just to be safe.
      const sure = window.confirm('Are you sure you want to delete this word?');
      if (!sure) return;

      try {
        // Call the API to delete vocabulary by ID.
      await api.deleteWord(id)
      this.words = this.words.filter(word => word._id !== id)
      alert('Word deleted successfully! 🗑️')
      } catch (error) {
        console.error("Error deleting word:", error);
        alert('Failed to delete word.');
      }
    }
  }
};
</script>

<style scoped>
.search-box {
  margin-bottom: 15px;
  max-width: 400px;
}
.sortable {
  cursor: pointer;
  user-select: none;
}
.sortable:hover {
  background-color: #f3f4f5;
}
.no-results {
  color: #999;
  padding: 20px 0;
}
</style>