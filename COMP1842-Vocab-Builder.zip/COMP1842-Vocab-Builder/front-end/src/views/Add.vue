<template>
  <div class="new-word-page">
    <div class="ui container">
      <h1 class="ui header">
        <i class="plus circle icon"></i>
        <div class="content">
          Add New Word
          <div class="sub header">Create a new vocabulary entry</div>
        </div>
      </h1>

      <div class="ui raised segment">
        <word-form :word="word" @createOrUpdate="createWord"></word-form>
      </div>
    </div>
  </div>
</template>

<script>
import WordForm from '../components/WordForm.vue';
import { api } from '../helpers/helpers';

export default {
  name: 'add-word',
  components: {
    'word-form': WordForm
  },
  data() {
    return {
      word: {
        german: '',
        english: '',
        french: ''
      }
    };
  },
  methods: {
    async createWord(newWord) {
      try {
        await api.createWord(newWord);
        // Redirect to the vocabulary list after successful creation
        this.$router.push('/words');
      } catch (error) {
        console.error('Error creating word:', error);
        alert('Failed to create the word. Please try again.');
      }
    }
  }
};
</script>

<style scoped>
.new-word-page {
  padding: 30px 0;
}

.ui.header {
  margin-bottom: 25px;
}

.ui.raised.segment {
  padding: 25px;
  max-width: 650px;
}
</style>