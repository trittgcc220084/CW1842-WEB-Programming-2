<template>
  <div>
    <h1>Vocabulary Test</h1>

    <!-- ===== STEP 1: Select languages ===== -->
    <div v-if="!testStarted" class="ui segment">
      <h3>Select exactly 2 languages to test:</h3>

      <div class="ui form">
        <div class="inline fields">
          <div class="field">
            <div class="ui checkbox">
              <input type="checkbox" v-model="selectedLanguages" value="english" id="lang-en">
              <label for="lang-en"><i class="united kingdom flag"></i> English</label>
            </div>
          </div>
          <div class="field">
            <div class="ui checkbox">
              <input type="checkbox" v-model="selectedLanguages" value="german" id="lang-de">
              <label for="lang-de"><i class="germany flag"></i> German</label>
            </div>
          </div>
          <div class="field">
            <div class="ui checkbox">
              <input type="checkbox" v-model="selectedLanguages" value="french" id="lang-fr">
              <label for="lang-fr"><i class="france flag"></i> French</label>
            </div>
          </div>
        </div>
      </div>

      <div v-if="selectedLanguages.length !== 2" class="ui warning message" style="margin-top: 15px;">
        Please select exactly 2 languages.
      </div>

      <button
        class="ui primary button"
        style="margin-top: 15px;"
        :disabled="selectedLanguages.length !== 2 || words.length === 0"
        @click="startTest"
      >
        Start Test
      </button>

      <div v-if="words.length === 0" class="ui message" style="margin-top: 15px;">
        You don't have any words to test yet. Please add some words first! 📝
      </div>
    </div>

    <!-- ===== STEP 2: Take the test ===== -->
    <div v-else>
      <div class="ui card fluid">
        <div class="content">
          <div class="header">
            What is the <strong>{{ targetLanguageLabel }}</strong> translation for:
          </div>
          <div class="meta" style="font-size: 1.5em; margin-top: 10px; color: #2185d0;">
            <i :class="sourceFlag"></i> {{ currentWord[sourceLanguage] }}
          </div>
        </div>

        <div class="content">
          <div class="ui form">
            <div class="field">
              <label>Your Answer ({{ targetLanguageLabel }}):</label>
              <input
                type="text"
                v-model="userAnswer"
                :placeholder="`Type the ${targetLanguageLabel} word here...`"
                @keyup.enter="checkAnswer"
              />
            </div>
            <button class="ui primary button" @click="checkAnswer">Check Answer</button>
            <button class="ui button" @click="resetTest" style="margin-left: 10px;">
              Change Languages
            </button>
          </div>
        </div>

        <div v-if="feedback" class="extra content">
          <div :class="['ui message', isCorrect ? 'success' : 'error']">
            {{ feedback }}
          </div>
          <button class="ui right floated button custom-next" @click="nextWord">
            Next Word ➡️
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { api } from '@/helpers/helpers';

export default {
  name: 'vocab-test',
  data() {
    return {
      words: [],
      currentWord: {},
      selectedLanguages: [],
      sourceLanguage: '',
      targetLanguage: '',
      userAnswer: '',
      feedback: '',
      isCorrect: false,
      testStarted: false
    };
  },
  computed: {
    targetLanguageLabel() {
      const labels = {
        english: 'English',
        german: 'German',
        french: 'French'
      };
      return labels[this.targetLanguage] || '';
    },
    sourceFlag() {
      const flags = {
        english: 'united kingdom flag',
        german: 'germany flag',
        french: 'france flag'
      };
      return flags[this.sourceLanguage] || '';
    }
  },
  async mounted() {
    this.words = await api.getWords();
  },
  methods: {
    startTest() {
      if (this.selectedLanguages.length !== 2) return;

      this.testStarted = true;
      this.pickRandomWord();
    },

    resetTest() {
      this.testStarted = false;
      this.selectedLanguages = [];
      this.userAnswer = '';
      this.feedback = '';
      this.currentWord = {};
    },

    pickRandomWord() {
      const randomIndex = Math.floor(Math.random() * this.words.length);
      this.currentWord = this.words[randomIndex];

      // Randomly decide which language is the question and which is the answer
      const shuffled = [...this.selectedLanguages].sort(() => Math.random() - 0.5);
      this.sourceLanguage = shuffled[0];
      this.targetLanguage = shuffled[1];

      this.userAnswer = '';
      this.feedback = ''; 
    },

    checkAnswer() {
      if (!this.userAnswer.trim()) return;

      const correctAnswer = this.currentWord[this.targetLanguage] || '';

      if (this.userAnswer.trim().toLowerCase() === correctAnswer.toLowerCase()) {
        this.feedback = 'Correct! Awesome job! 🎉';
        this.isCorrect = true;
      } else {
        this.feedback = `Incorrect! The correct answer was: "${correctAnswer}"`;
        this.isCorrect = false;
      }
    },

    nextWord() {
      this.pickRandomWord();
    }
  }
};
</script>

<style scoped>
.extra.content {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-top: 15px;
}

.custom-next {
  align-self: flex-end;
  margin-top: 0 !important;
}
</style>