<template>
  <div class="about-page">
    <h1 class="ui header">
      <i class="book icon"></i>
      <div class="content">
        Vocab Builder
        <div class="sub header">A simple MEVN-stack vocabulary trainer</div>
      </div>
    </h1>

    <p class="intro">
      <strong>Vocab Builder</strong> lets you add, edit and review vocabulary
      across three languages — English, German and French — then practise
      what you've learned with a random vocabulary test.
    </p>

    <!-- Data automatically retrieved from the API. -->
    <div class="ui three statistics">
      <div class="statistic">
        <div class="value">
          <span v-if="loading">…</span>
          <span v-else>{{ totalWords }}</span>
        </div>
        <div class="label">Words stored</div>
      </div>
      <div class="statistic">
        <div class="value">3</div>
        <div class="label">Languages</div>
      </div>
      <div class="statistic">
        <div class="value">
          <span v-if="loading">…</span>
          <span v-else>{{ totalWords * 3 }}</span>
        </div>
        <div class="label">Translations</div>
      </div>
    </div>

    <div v-if="errorLoading" class="ui warning message">
      Couldn't load live stats from the server — showing 0 for now.
    </div>

    <h3 class="ui dividing header">Features</h3>
    <div class="ui three cards">
      <div class="ui card">
        <div class="content">
          <div class="header"><i class="edit outline icon"></i> Full CRUD</div>
          <div class="description">
            Add, view, edit and delete vocabulary entries stored in MongoDB.
          </div>
        </div>
      </div>
      <div class="ui card">
        <div class="content">
          <div class="header"><i class="language icon"></i> 3 Languages</div>
          <div class="description">
            Every word is stored with its English, German and French translation.
          </div>
        </div>
      </div>
      <div class="ui card">
        <div class="content">
          <div class="header"><i class="graduation cap icon"></i> Practice Test</div>
          <div class="description">
            Random quiz between any two of the three languages with instant feedback.
          </div>
        </div>
      </div>
    </div>

    <h3 class="ui dividing header">Tech Stack</h3>
    <div class="ui four item horizontal list tech-stack">
      <div class="item"><i class="database icon"></i> MongoDB</div>
      <div class="item"><i class="server icon"></i> Express</div>
      <div class="item"><i class="vuejs icon"></i> Vue.js</div>
      <div class="item"><i class="node js icon"></i> Node.js</div>
    </div>

    <p class="author">Built as part of the COMP1842 coursework.</p>
  </div>
</template>

<script>
import { api } from '../helpers/helpers';

export default {
  name: 'about',
  data() {
    return {
      totalWords: 0,
      loading: true,
      errorLoading: false
    };
  },
  async mounted() {
    try {
      const words = await api.getWords();
      this.totalWords = words.length;
    } catch (error) {
      console.error("Error loading statistics:", error);
      this.errorLoading = true;
    } finally {
      this.loading = false;
    }
  }
};
</script>

<style scoped>
.about-page {
  max-width: 800px;
}
.intro {
  font-size: 1.05em;
  color: #4a4a4a;
  margin-bottom: 25px;
}
.tech-stack .item {
  font-size: 1.05em;
}
.author {
  margin-top: 30px;
  font-style: italic;
  color: #767676;
}
</style>