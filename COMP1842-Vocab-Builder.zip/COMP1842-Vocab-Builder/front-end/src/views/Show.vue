<template>
  <div>
    <h1>Show Word</h1>

    <div v-if="word">
      <div class="ui labeled input fluid">
        <div class="ui label">
          <i class="germany flag"></i> German
        </div>
        <input type="text" readonly :value="word.german" />
      </div>

      <div class="ui labeled input fluid" style="margin-top: 10px;">
        <div class="ui label">
          <i class="united kingdom flag"></i> English
        </div>
        <input type="text" readonly :value="word.english" />
      </div>

      <div class="ui labeled input fluid" style="margin-top: 10px;">
        <div class="ui label">
          <i class="france flag"></i> French
        </div>
        <input type="text" readonly :value="word.french" />
      </div>
    </div>

    <div v-else class="ui active inline loader"></div>

    <div class="actions">
      <router-link :to="{ name: 'edit', params: { id: this.$route.params.id }}">
        Edit word
      </router-link>
      <router-link :to="{ name: 'words' }">
        Back to list
      </router-link>
    </div>
  </div>
</template>

<script>
import { api } from '../helpers/helpers';

export default {
  name: 'show',
  data() {
    return {
      word: null
    };
  },
  async mounted() {
    try {
      this.word = await api.getWord(this.$route.params.id);
    } catch (error) {
      console.error("Error loading vocabulary details:", error);
    }
  }
};
</script>

<style scoped>
.actions a {
  display: block;
  text-decoration: underline;
  margin: 20px 10px;
}
</style>