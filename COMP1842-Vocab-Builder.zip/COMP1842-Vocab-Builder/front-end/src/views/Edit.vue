<template>
  <div class="edit-word-page">
    <div class="ui container">
      <h1 class="ui header">
        <i class="edit icon"></i>
        <div class="content">
          Edit Word
          <div class="sub header">Update an existing vocabulary entry</div>
        </div>
      </h1>

      <div class="ui raised segment">
         <word-form 
          :word="word" 
          :is-edit="true"
          @createOrUpdate="createOrUpdate"
        ></word-form>

        <div class="button-group">
          <button class="ui button" @click="goBack">
            <i class="arrow left icon"></i> Back to List
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import WordForm from '../components/WordForm.vue';
import { api } from '../helpers/helpers';

export default {
  name: 'edit',
  components: {
    'word-form': WordForm
  },
  data() {
    return {
      word: {}
    };
  },
  async mounted() {
    this.word = await api.getWord(this.$route.params.id);
  },
  methods: {
    async createOrUpdate(word) {
      try {
        await api.updateWord(word);
        alert('Word updated successfully!');
        this.$router.push(`/words/${this.$route.params.id}`);
      } catch (error) {
        console.error('Error updating word:', error);
        alert('Failed to update the word. Please try again.');
      }
    },
    goBack() {
      this.$router.push('/words');
    }
  }
};
</script>

<style scoped>
.edit-word-page {
  padding: 30px 0;
}

.ui.header {
  margin-bottom: 25px;
}

.ui.raised.segment {
  padding: 25px;
  max-width: 650px;
}

.button-group {
  margin-top: 20px;
  padding-top: 15px;
  border-top: 1px solid #e0e0e0;
}

</style>