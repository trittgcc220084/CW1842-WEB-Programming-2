import axios from 'axios'
import Vue from 'vue'
import VueFlashMessage from 'vue-flash-message'
import 'vue-flash-message/dist/vue-flash-message.min.css'

Vue.use(VueFlashMessage, {
   messageOptions: {
      timeout: 3000,
      pauseOnInteract: true
   }
})

const vm = new Vue()
const baseURL = 'http://localhost:8000/vocabs/'

const handleError = fn => async (...params) => {
  try {
    return await fn(...params)
  } catch (error) {
    const status = error.response?.status || 'Network'
    const text = error.response?.statusText || error.message
    vm.flash(`${status}: ${text}`, 'error')
    throw error  
  }
}

export const api = {
   getWord: handleError(async (id) => {
      const res = await axios.get(baseURL + id)
      return res.data
   }),
   getWords: handleError(async () => {
      const res = await axios.get(baseURL)
      console.log(res.data)
      return res.data
      
   }),
   deleteWord: handleError(async (id) => {
      const res = await axios.delete(baseURL + id)
      return res.data
   }),
   createWord: handleError(async (payload) => {
      const res = await axios.post(baseURL, payload)
      return res.data
   }),
   updateWord: handleError(async (payload) => {
      const res = await axios.put(baseURL + payload._id, payload)
      return res.data
   })
}

