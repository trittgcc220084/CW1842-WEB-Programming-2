import Vue from 'vue'
import Router from 'vue-router'

import Words from './views/Words.vue'       
import AddWord from './views/Add.vue'     
import EditWord from './views/Edit.vue'   
import ShowWord from './views/Show.vue'   
import Test from './views/Test.vue'
import About from './views/About.vue'

Vue.use(Router)

export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  linkActiveClass: 'active', 
  routes: [
    {
      path: '/',
      redirect: '/words'
    },
    {
      path: '/words',
      name: 'words',
      component: Words
    },
    {
      path: '/words/new',
      name: 'new-word',
      component: AddWord 
    },
    {
      path: '/words/:id',
      name: 'show',       
      component: ShowWord 
    },
    {
      path: '/words/:id/edit',
      name: 'edit',
      component: EditWord 
    },
    {
      path: '/test',
      name: 'test',
      component: Test
    },
    {
      path: '/about',
      name: 'about',
      component: About
    }
  ]  
});