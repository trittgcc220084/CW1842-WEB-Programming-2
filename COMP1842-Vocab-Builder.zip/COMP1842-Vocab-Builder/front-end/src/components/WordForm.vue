<template>
  <form class="ui form" @submit.prevent="onSubmit">
    <!-- Error message -->
    <div v-if="errorsPresent" class="ui negative message">
      <i class="exclamation triangle icon"></i>
      Please fill out all fields!
    </div>

    <!-- German -->
    <div class="field">
      <label>
        <i class="germany flag"></i> German
      </label>
      <div class="ui fluid input">
        <input
          type="text"
          placeholder="Enter German word..."
          v-model="word.german"
        />
      </div>
    </div>

    <!-- English -->
    <div class="field">
      <label>
        <i class="united kingdom flag"></i> English
      </label>
      <div class="ui fluid input">
        <input
          type="text"
          placeholder="Enter English word..."
          v-model="word.english"
        />
      </div>
    </div>

    <!-- French -->
    <div class="field">
      <label>
        <i class="france flag"></i> French
      </label>
      <div class="ui fluid input">
        <input
          type="text"
          placeholder="Enter French word..."
          v-model="word.french"
        />
      </div>
    </div>

    <!-- Submit button -->
    <button class="ui primary button" type="submit">
      <i :class="isEdit ? 'save icon' : 'plus icon'"></i>
      {{ isEdit ? 'Update Word' : 'Add Word' }}
    </button>
  </form>
</template>

<script>
export default {
  name: 'word-form',
  props: {
    word: {
      type: Object,
      required: false,
      default: () => ({
        german: '',
        english: '',
        french: ''
      })
    },
// true = Edit page, false = New pageHTML
    isEdit: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      errorsPresent: false
    };
  },
  methods: {
    onSubmit() {
      if (
        !this.word.english?.trim() ||
        !this.word.german?.trim() ||
        !this.word.french?.trim()
      ) {
        this.errorsPresent = true;
      } else {
        this.errorsPresent = false;
        this.$emit('createOrUpdate', this.word);
      }
    }
  }
};
</script>

<style scoped>
.ui.form .field {
  margin-bottom: 18px;
}

.ui.form label {
  font-weight: 600;
  margin-bottom: 6px;
  display: block;
}

.ui.primary.button {
  margin-top: 10px;
}
</style>