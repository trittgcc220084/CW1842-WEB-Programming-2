import Vue from 'vue'
import App from './App.vue'
import router from './router'

// Global Semantic UI styles
import 'semantic-ui-css/semantic.min.css'

// Suppress the production-tip message in the browser console
Vue.config.productionTip = false

// Create and mount the root Vue instance
new Vue({
  router,
  render: function (h) { return h(App) },
}).$mount('#app')