const express = require("express");
const app = express();
const port = 8000;


const cors = require('cors');
app.use(cors());


const mongoose = require('mongoose');
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/vocab-builder')
.then(() => console.log("Connected to MongoDB"))
.catch(err => console.error("Could not connect to MongoDB", err));

require('./api/models/vocabmodels');
// Import route modules
const vocabRoutes = require("./api/routes/vocabs");

app.use(express.json()); // Middleware to handle JSON body

 // Use routes
app.use("/vocabs", vocabRoutes);

// Start server
app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});