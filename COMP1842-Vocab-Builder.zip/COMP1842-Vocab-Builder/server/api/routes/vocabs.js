const express = require("express");
const router = express.Router();

const vocabsController = require("../controllers/vocabsController");

// List all vocabulary entries
router.get("/", vocabsController.getVocabs);

// Get one vocabulary entry by ID
router.get("/:id", vocabsController.getVocab);

// Create a new vocabulary entry
router.post("/", vocabsController.createVocab);

// Update an existing vocabulary entry
router.put("/:id", vocabsController.updateVocab);

// Delete a vocabulary entry
router.delete("/:id", vocabsController.deleteVocab);

module.exports = router;
