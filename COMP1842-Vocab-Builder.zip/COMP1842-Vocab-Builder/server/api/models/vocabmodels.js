const mongoose = require('mongoose');

const vocabSchema = new mongoose.Schema(
  {
    // English translation – required
    english: { type: String, required: true },

    // German translation – required
    german:  { type: String, required: true },

    // French translation – required (third language field)
    french:  { type: String, required: true }
  },
  {
    // Store documents in the "vocab" collection
    collection: 'vocab'
  }
);

// Export the model so controllers can use it
module.exports = mongoose.model('Vocab', vocabSchema);