const mongoose = require('mongoose');
const Vocab = mongoose.model('Vocab');

// GET all vocabs
exports.getVocabs = async (req, res) => {
    try {
        const vocabs = await Vocab.find({});
        res.json(vocabs);
    } catch (err) {
        res.status(500).send(err);
    }
};

// GET one vocab by ID
exports.getVocab = async (req, res) => {
    try {
        const vocab = await Vocab.findById(req.params.id);
        if (!vocab) return res.status(404).json({ message: 'Vocab not found' });
        res.json(vocab);
    } catch (err) {
        res.status(500).send(err);
    }
};

// POST create new vocab
exports.createVocab = async (req, res) => {
    try {
        const newVocab = new Vocab(req.body);
        const vocab = await newVocab.save();
        res.json(vocab);
    } catch (err) {
        res.status(500).send(err);
    }
};

// PUT update vocab
exports.updateVocab = async (req, res) => {
    try {
        const vocab = await Vocab.findOneAndUpdate(
            { _id: req.params.id },
            req.body,
            { new: true, runValidators: true }
        );
        if (!vocab) return res.status(404).json({ message: 'Vocab not found' });
        res.json(vocab);
    } catch (err) {
        res.status(500).send(err);
    }
};

// DELETE vocab
exports.deleteVocab = async (req, res) => {
    try {
        const result = await Vocab.deleteOne({ _id: req.params.id });
        if (result.deletedCount === 0) {
            return res.status(404).json({ message: 'Vocab not found' });
        }
        res.json({ message: 'Vocab successfully deleted' });
    } catch (err) {
        res.status(500).send(err);
    }
};