const app = Vue.createApp({
    data() {
        return {
            product: 'Socks',
            name: 'To Thanh Tri GCC220084',
            image: '../assets/images/socks_green.jpg',
            inventory: 100,
            onSale: true 
        }
    }
})