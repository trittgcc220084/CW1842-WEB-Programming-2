const app = Vue.createApp({
    data() {
        return {
            product: 'Socks',
            description: 'A warm and comfortable pair of socks.',
            name: 'To Thanh Tri GCC220084',
            image: '../assets/images/socks_green.jpg',
            url: 'https://www.vuemastery.com/'
        }
    }
})