app.component('product-display', {

    props: {
        premium: {
            type: Boolean,
            required: true
        }
    },

    template: /*html*/ `
    <div class="product-display">
        <div class="product-container">
            <div class="product-image">
                <img 
                    :src="image"
                    :class="{ 'out-of-stock-img': !inStock }"
                >
            </div>

            <div class="product-info">
                <h2>To Thanh Tri GCC220084 - VueJS Lesson 10</h2>
                <h1>{{ title }}</h1>

                <p v-if="inStock">In Stock</p>
                <p v-else>Out of Stock</p>

                <p>{{ saleMessage }}</p>
                <p>Shipping: {{ shipping }}</p>

                <product-details :details="details"></product-details>

                <div v-for="(variant, index) in variants" 
                     :key="variant.id"
                     class="color-circle"
                     :style="{ backgroundColor: variant.color }"
                     @mouseover="updateVariant(index)">
                </div>

                <div class="button-group">
                    <button 
                        class="button"
                        :class="{ disabledButton: !inStock }"
                        :disabled="!inStock"
                        @click="addToCart">
                        Add To Cart
                    </button>

                    <button 
                        class="button remove-btn"
                        :class="{ disabledButton: !inStock }"
                        :disabled="!inStock"
                        @click="removeFromCart">
                        Remove
                    </button>
                </div>
            </div>
        </div>
    </div>
    `,

    data() {
        return {
            product: 'Socks',
            brand: 'Vue Mastery',
            selectedVariant: 0,
            onSale: true,

            details: ['50% cotton', '30% wool', '20% polyester'],

            variants: [
                { id: 2234, color: 'green', image: './assets/images/socks_green.jpg', quantity: 50 },
                { id: 2235, color: 'blue', image: './assets/images/socks_blue.jpg', quantity: 0 }
            ]
        }
    },

    methods: {
        addToCart() {
            this.$emit('add-to-cart', this.variants[this.selectedVariant].id)
        },

        removeFromCart() {
            this.$emit('remove-from-cart', this.variants[this.selectedVariant].id)
        },

        updateVariant(index) {
            this.selectedVariant = index
        }
    },

    computed: {
        title() {
            return this.brand + ' ' + this.product
        },
        image() {
            return this.variants[this.selectedVariant].image
        },
        inStock() {
            return this.variants[this.selectedVariant].quantity > 0   
        },
        saleMessage() {
            if (this.onSale) return this.brand + ' ' + this.product + ' is on sale'
            return this.brand + ' ' + this.product
        },
        shipping() {
            return this.premium ? 'Free' : 2.99
        }
    }
})