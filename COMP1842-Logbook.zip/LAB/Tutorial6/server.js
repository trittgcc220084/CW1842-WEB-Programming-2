const http = require("http");

const server = http.createServer((req, res) => {

    if (req.url === "/") {
        res.writeHead(200, {"Content-Type": "text/html; charset=utf-8"});
        res.end(`
            <h1>To Thanh Tri - GCC220084</h1>
            <hr>
            <p>This is home Page.</p>
        `);
    }

    else if (req.url === "/student") {
        res.writeHead(200, {"Content-Type": "text/html; charset=utf-8"});
        res.end(`
            <h1>To Thanh Tri - GCC220084</h1>
            <hr>
            <p>This is student Page.</p>
        `);
    }

    else if (req.url === "/admin") {
        res.writeHead(200, {"Content-Type": "text/html; charset=utf-8"});
        res.end(`
            <h1>To Thanh Tri - GCC220084</h1>
            <hr>
            <p>This is admin Page.</p>
        `);
    }

    else if (req.url === "/data") {
        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ "message": "Hello World JSON" }));
    }

    else {
        res.writeHead(400, {"Content-Type": "text/html; charset=utf-8"});
        res.end(`
            <h1>To Thanh Tri - GCC220084</h1>
            <hr>
            <p>Invalid Request!</p>
        `);
    }
});

server.listen(8080, () => {
    console.log("Node.js web server at port 8080 is running... GCC220084");
});